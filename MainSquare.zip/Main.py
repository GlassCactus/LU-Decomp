# Austin H Kim
# CECS 328
# Snake Witches (so cLEEAAAAAN i think)

from fractions import Fraction

def printMatrix(matrix, n):
    for i in range(n):
        for j in range(n):
            print(matrix[i][j], end=" ")
        print()

def printSol(x, n):
    for i in range(n):
        print(x[i][0], end="")
        print()


def LUdecomposition(matrix, n):
    L = [[0] * n for i in range(n)]
    U = [[0] * n for i in range(n)]

    for i in range(n):
        L[i][i] = 1

    for k in range(n):
        U[k][k] = matrix[k][k]
        i = k + 1

        while i < n:
            L[i][k] = matrix[i][k] / U[k][k]
            U[k][i] = matrix[k][i]
            i += 1

        i = k + 1

        while i < n:
            j = k + 1

            while j < n:
                matrix[i][j] = matrix[i][j] - (L[i][k] * U[k][j])
                j += 1

            i += 1

    return L, U

def LUsolve(L, U, b, x, n):

    y = [[0] for i in range(n)]

    # Forward Substitution
    for i in range(n):
        j = 0
        tempSum = 0

        while j < i:
            tempSum += L[i][j] * y[j][0]
            j += 1

        y[i][0] = b[i][0] - tempSum

    # Backward Substitution (wORK PLEASE)
    for i in range(n):
        i = (n - 1) - i
        j = i + 1
        tempSum = 0

        while j < n:
            tempSum += U[i][j] * x[j][0]
            j += 1

        x[i][0] = (y[i][0] - tempSum) / U[i][i]

    return x


if __name__ == "__main__":
    f = open("input.txt", "r")
    firstLine = f.readline().split(":")
    n = len(firstLine)
    b = [[0] for i in range(n)]
    x = [[0] for i in range(n)]
    matrix = [[0] * n for i in range(n)]

    for i in range(n):
        b[i][0] = int(firstLine[i])

    for i in range(n):
        nextLine = f.readline().split(":")
        for j in range(n):
            matrix[j][i] = int(nextLine[j])

    f.close()

    L, U = LUdecomposition(matrix, n)
    x = LUsolve(L, U, b, x, n)

    ratio = (Fraction(x[0][0]).limit_denominator())
    ratio = int(ratio.denominator)

    for i in range(n):
        x[i][0] = int(round(x[i][0] * ratio))

    printSol(x, n)

    f = open("output.txt", "w+")

    for i in range(n):
        f.write("%d\n" % x[i][0])

    f.close()
